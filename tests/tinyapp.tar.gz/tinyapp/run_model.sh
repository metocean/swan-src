/usr/local/bin/mpiexec -n 2 /usr/local/bin/swan.exe par.20170101_00z_native.swn
